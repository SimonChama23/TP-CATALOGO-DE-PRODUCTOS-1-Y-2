import React, { useEffect } from 'react';
import './App.css';
import { ActionTypes, useContextState } from "./contextState";

function Detalle() {
  const { contextState, setContextState } = useContextState();

  useEffect(() => {
    const response = fetch(
      `https://dummyjson.com/cars/1`, 
      {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      }
    )
      .then(async (response) => {
        const detallesAuto = await response.json();
        setContextState({
          newValue: detallesAuto,
          type: ActionTypes.setDetallado,
        });
        setContextState({ newValue: false, type: 'SET_LOADING' });
      })
      .catch((error) => {
        alert(JSON.stringify(error));
        console.error(error);
      });
  }, []);

  return (
    <>
      <div className="container text-center detalle">
        <div className="row">
          <div className="col">
            <img src="https://media.a24.com/p/22a7927e78359e9fee9e656654aa9f1a/adjuntos/296/imagenes/008/168/0008168432/los-mejores-autos-clasicos-argentinos.jpeg" className="card-img-top imagenDetalle" alt="Auto" />
          </div>
          <div className="col">
            <ul className='text-center centrar'>
              <h2>Detalles del Auto</h2> 
              <br /><br /><br /><br />
              <li>Marca: {contextState.marca}</li> 
              <li>Modelo: {contextState.modelo}</li> 
              <li>Año: {contextState.anno}</li> 
              <li>Color: {contextState.color}</li> 
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default Detalle;

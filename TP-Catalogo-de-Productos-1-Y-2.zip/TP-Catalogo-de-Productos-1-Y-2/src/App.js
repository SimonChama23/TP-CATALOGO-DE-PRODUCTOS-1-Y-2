import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import Home from './Home';
import Productos from './Productos';
import Detalle from './Detalle';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="productos" element={<Productos />} />
          <Route path="detalle" element={<Detalle />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;

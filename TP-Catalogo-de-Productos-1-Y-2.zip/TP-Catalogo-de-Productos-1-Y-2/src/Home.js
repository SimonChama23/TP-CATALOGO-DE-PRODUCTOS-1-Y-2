import React from 'react';
import Carusel from './Carrusel';

const Home = () => {
  return (
    <>
      <Carusel />
    </>
  );
}

export default Home;

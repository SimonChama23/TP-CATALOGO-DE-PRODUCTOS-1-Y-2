import React from "react";
import "./App.css";
import { useContextState } from "./contextState";

export default function Card() {
  const { contextState } = useContextState();

  const Tarjeta = ({ producto }) => {
    return (
      <div className="col">
        <div className="card">
          <img src={producto.thumbnail} className="card-img-top imagen" alt="..." />
          <div className="card-body">
            <h5 className="card-title">{producto.title}</h5>
            <p className="card-text">Precio: ${producto.price}</p>
            <button className="btn btn-primary">ver detalles</button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="container text-center">
      <div className="row">
        {contextState.busqueda.map((producto) => (
          <Tarjeta key={producto.id} producto={producto} />
        ))}
      </div>
    </div>
  );
}
